# Lycanites Overlay Fix (NeoForge 1.21.1)
Arregla `NullPointerException: Cannot invoke Minecraft.getTextureManager() because BaseOverlayScreen.getMinecraft() is null`
en `MobEventPlayerClient.onGUIUpdate` (Lycanites Mobs Reloaded 0.0.1) sin quitar el cartel de eventos.
Compilar: `gradlew build` -> build/libs/lycanites_overlay_fix-1.1.0.jar -> carpeta mods/
